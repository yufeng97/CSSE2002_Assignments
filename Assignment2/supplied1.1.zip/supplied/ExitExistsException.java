/**
 * An attempt was made to add an exit in a direction which already has one.
 *
 * @author JF
 * @serial exclude
 */
public class ExitExistsException extends CrawlException {}
