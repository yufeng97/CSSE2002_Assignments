/**
 * An attempt was made to add an exit to null rather than a valid room.
 *
 * @author JF
 * @serial exclude
 */
public class NullRoomException extends CrawlException {}
