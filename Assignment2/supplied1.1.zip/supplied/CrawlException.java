/**
 * Base class for custom exceptions in Crawl.
 *
 * @author JF
 * @serial exclude
 */
public class CrawlException extends Exception {}
